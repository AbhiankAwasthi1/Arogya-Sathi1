"use client"

import { Button } from "@/components/ui/button"
import { Settings, Globe, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export function PatientNav() {
  const [activeTab, setActiveTab] = useState("home")

  const sosNumbers = [
    { number: "112", label: "Universal Emergency Number" },
    { number: "108", label: "Emergency Ambulance Service" },
    { number: "102", label: "National Ambulance Service" },
    { number: "104", label: "Medical Helpline" },
    { number: "1075", label: "COVID-19 Helpline" },
    { number: "101", label: "Alternate Emergency line" },
  ]

  const handleSOS = () => {
    const confirmed = window.confirm("Do you need emergency assistance? This will show emergency numbers.")
    if (confirmed) {
      const numbers = sosNumbers.map((n) => `${n.number} - ${n.label}`).join("\n")
      alert(`Emergency Numbers:\n\n${numbers}`)
    }
  }

  return (
    <nav className="bg-card border-b border-border p-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Left - Settings */}
        <Button variant="outline" size="lg" asChild>
          <Link href="/patient/settings">
            <Settings className="w-5 h-5 mr-2" />
            Settings
          </Link>
        </Button>

        {/* Center - Navigation */}
        <div className="flex space-x-2">
          <Button
            variant={activeTab === "home" ? "default" : "outline"}
            size="lg"
            onClick={() => setActiveTab("home")}
            asChild
          >
            <Link href="/patient">Home</Link>
          </Button>
          <Button
            variant={activeTab === "symptoms" ? "default" : "outline"}
            size="lg"
            onClick={() => setActiveTab("symptoms")}
            asChild
          >
            <Link href="/patient/symptoms">Symptoms</Link>
          </Button>
          <Button
            variant={activeTab === "ai" ? "default" : "outline"}
            size="lg"
            onClick={() => setActiveTab("ai")}
            asChild
          >
            <Link href="/patient/ai-assistant">AI Assistant</Link>
          </Button>
        </div>

        {/* Right - Language & SOS */}
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/patient/language">
              <Globe className="w-4 h-4 mr-1" />
              Not your native language? Click on this icon to change your language
            </Link>
          </Button>
          <Button variant="destructive" size="lg" onClick={handleSOS}>
            <AlertTriangle className="w-5 h-5 mr-2" />
            SOS
          </Button>
        </div>
      </div>
    </nav>
  )
}
