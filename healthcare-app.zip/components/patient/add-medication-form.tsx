"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Plus } from "lucide-react"

interface AddMedicationFormProps {
  onAdd: (medication: any) => void
}

export function AddMedicationForm({ onAdd }: AddMedicationFormProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    dosage: "",
    frequency: "",
    reminderTime: "",
    instructions: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const newMedication = {
      id: Date.now().toString(),
      ...formData,
      nextDue: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      taken: false,
    }

    onAdd(newMedication)
    setFormData({ name: "", dosage: "", frequency: "", reminderTime: "", instructions: "" })
    setIsOpen(false)
    setLoading(false)
  }

  const handleCantAdd = () => {
    alert("Request sent to your caretaker. They will add the medication for you.")
  }

  if (!isOpen) {
    return (
      <div className="space-y-4">
        <Button size="lg" className="w-full text-lg py-6" onClick={() => setIsOpen(true)}>
          <Plus className="w-5 h-5 mr-2" />
          Add Medication
        </Button>

        <Button
          variant="outline"
          size="lg"
          className="w-full text-lg py-6 border-2 border-blue-500 text-blue-600 bg-transparent"
          onClick={handleCantAdd}
        >
          can't add medication by yourself? Your caretaker will add it for you
        </Button>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Add New Medication</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Medication Name</Label>
            <Input
              id="name"
              placeholder="e.g., Combiflam, Aspirin"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dosage">Dosage</Label>
            <Input
              id="dosage"
              placeholder="e.g., 500 mg, 1 tablet"
              value={formData.dosage}
              onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
              required
              className="text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="frequency">Frequency</Label>
            <Input
              id="frequency"
              placeholder="Once Daily"
              value={formData.frequency}
              onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
              required
              className="text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reminderTime">Reminder Time</Label>
            <Input
              id="reminderTime"
              placeholder="e.g., 10 pm"
              value={formData.reminderTime}
              onChange={(e) => setFormData({ ...formData, reminderTime: e.target.value })}
              required
              className="text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="instructions">Instructions (Optional)</Label>
            <Textarea
              id="instructions"
              placeholder="e.g., Take with food, on empty stomach"
              value={formData.instructions}
              onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
              className="text-lg min-h-[100px]"
            />
          </div>

          <div className="flex space-x-3">
            <Button type="submit" size="lg" className="flex-1 text-lg py-6" disabled={loading}>
              {loading ? "Adding..." : "Add Medication"}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="flex-1 text-lg py-6 bg-transparent"
              onClick={() => setIsOpen(false)}
            >
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
