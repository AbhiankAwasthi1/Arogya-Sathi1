"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Clock } from "lucide-react"
import { useState } from "react"

interface Medication {
  id: string
  name: string
  dosage: string
  frequency: string
  instructions?: string
  caution?: string
  nextDue: Date
  taken: boolean
}

interface MedicationCardProps {
  medication: Medication
  onMarkTaken: (id: string) => void
  onMarkMissed: (id: string) => void
}

export function MedicationCard({ medication, onMarkTaken, onMarkMissed }: MedicationCardProps) {
  const [loading, setLoading] = useState(false)

  const getTimeUntilDue = () => {
    const now = new Date()
    const diff = medication.nextDue.getTime() - now.getTime()
    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    if (diff < 0) {
      return "Overdue"
    } else if (hours === 0) {
      return `Due in ${minutes} minutes`
    } else {
      return `In ${hours} hours to take ${medication.name}`
    }
  }

  const handleAction = async (action: "taken" | "missed") => {
    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate API call

    if (action === "taken") {
      onMarkTaken(medication.id)
    } else {
      onMarkMissed(medication.id)
    }
    setLoading(false)
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-xl font-bold">{medication.name}</CardTitle>
            <p className="text-lg text-muted-foreground mt-1">{medication.dosage}</p>
          </div>
          <Badge variant="outline" className="text-base px-3 py-1">
            {medication.frequency}
          </Badge>
        </div>

        {medication.caution && (
          <div className="flex items-center mt-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2 flex-shrink-0" />
            <p className="text-sm text-yellow-800 dark:text-yellow-200">{medication.caution}</p>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center text-muted-foreground">
          <Clock className="w-4 h-4 mr-2" />
          <span className="text-lg">{getTimeUntilDue()}</span>
        </div>

        {medication.instructions && <p className="text-base text-muted-foreground">{medication.instructions}</p>}

        {!medication.taken && (
          <div className="flex space-x-3">
            <Button size="lg" className="flex-1 text-lg py-6" onClick={() => handleAction("taken")} disabled={loading}>
              {loading ? "Marking..." : "Taken"}
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="flex-1 text-lg py-6 bg-transparent"
              onClick={() => handleAction("missed")}
              disabled={loading}
            >
              Mark as Missed
            </Button>
          </div>
        )}

        {medication.taken && (
          <Badge variant="secondary" className="w-full justify-center text-lg py-2">
            ✓ Taken
          </Badge>
        )}
      </CardContent>
    </Card>
  )
}
