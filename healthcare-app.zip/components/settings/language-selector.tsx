"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Globe, Check } from "lucide-react"

const languages = [
  { code: "en", name: "English", nativeName: "English" },
  { code: "bn", name: "Bengali", nativeName: "বাংলা" },
  { code: "mr", name: "Marathi", nativeName: "मराठी" },
  { code: "ta", name: "Tamil", nativeName: "தமிழ்" },
  { code: "te", name: "Telugu", nativeName: "తెలుగు" },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी" },
]

export function LanguageSelector() {
  const [selectedLanguage, setSelectedLanguage] = useState("en")
  const [isOpen, setIsOpen] = useState(false)

  const handleLanguageChange = (languageCode: string) => {
    setSelectedLanguage(languageCode)
    setIsOpen(false)
    // In a real app, this would trigger i18n language change
    console.log("Language changed to:", languageCode)
  }

  const currentLanguage = languages.find((lang) => lang.code === selectedLanguage)

  if (!isOpen) {
    return (
      <Button variant="outline" onClick={() => setIsOpen(true)} className="text-base">
        <Globe className="w-4 h-4 mr-2" />
        Not your native language? Click on this icon to change your language
      </Button>
    )
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-xl flex items-center">
          <Globe className="w-5 h-5 mr-2" />
          Select Language
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {languages.map((language) => (
          <Button
            key={language.code}
            variant={selectedLanguage === language.code ? "default" : "outline"}
            className="w-full justify-between text-lg py-6"
            onClick={() => handleLanguageChange(language.code)}
          >
            <div className="flex items-center">
              <span className="font-medium">{language.name}</span>
              <span className="ml-2 text-muted-foreground">({language.nativeName})</span>
            </div>
            {selectedLanguage === language.code && <Check className="w-5 h-5" />}
          </Button>
        ))}

        <Button variant="ghost" onClick={() => setIsOpen(false)} className="w-full text-lg py-6">
          Cancel
        </Button>
      </CardContent>
    </Card>
  )
}
