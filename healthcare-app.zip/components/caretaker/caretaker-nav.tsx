"use client"

import { Button } from "@/components/ui/button"
import { Settings } from "lucide-react"
import Link from "next/link"

export function CaretakerNav() {
  return (
    <nav className="bg-card border-b border-border p-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Left - Settings */}
        <Button variant="outline" size="lg" asChild>
          <Link href="/caretaker/settings">
            <Settings className="w-5 h-5 mr-2" />
            Settings
          </Link>
        </Button>

        {/* Center - Title */}
        <h1 className="text-2xl font-bold">Caretaker Dashboard</h1>

        {/* Right - Add Actions */}
        <div className="flex space-x-2">
          <Button variant="outline" size="lg" asChild>
            <Link href="/caretaker/add-patient">Add Patient</Link>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link href="/caretaker/add-caretaker">Add Caretaker</Link>
          </Button>
        </div>
      </div>
    </nav>
  )
}
