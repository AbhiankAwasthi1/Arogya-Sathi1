"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Phone } from "lucide-react"
import Link from "next/link"

interface Patient {
  id: string
  name: string
  phone: string
  avatar?: string
  priority: "low" | "medium" | "high"
  adherence: number
  recentMisses: number
  lastActivity: Date
}

interface PatientRowProps {
  patient: Patient
  onPriorityChange: (id: string, priority: "low" | "medium" | "high") => void
}

export function PatientRow({ patient, onPriorityChange }: PatientRowProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getPriorityVariant = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive"
      case "medium":
        return "secondary"
      case "low":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const handleCall = () => {
    window.open(`tel:${patient.phone}`, "_self")
  }

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1">
            {/* Avatar */}
            <Avatar className="w-16 h-16">
              <AvatarImage src={patient.avatar || "/placeholder.svg"} alt={patient.name} />
              <AvatarFallback className="text-lg font-semibold">
                {patient.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>

            {/* Patient Info */}
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h3 className="text-xl font-semibold">{patient.name}</h3>
                <div className={`w-4 h-4 rounded ${getPriorityColor(patient.priority)}`} />
              </div>

              <div className="flex items-center space-x-4 text-muted-foreground">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCall}
                  className="p-0 h-auto font-normal text-muted-foreground hover:text-foreground"
                >
                  <Phone className="w-4 h-4 mr-1" />
                  {patient.phone}
                </Button>
                <span>•</span>
                <span>{patient.adherence}% adherence</span>
                <span>•</span>
                <span className={patient.recentMisses > 0 ? "text-red-600" : ""}>
                  {patient.recentMisses} misses in last 3 days
                </span>
              </div>
            </div>

            {/* Priority Controls */}
            <div className="flex flex-col space-y-2">
              <label className="text-sm font-medium">Priority:</label>
              <div className="flex space-x-1">
                {(["low", "medium", "high"] as const).map((priority) => (
                  <Button
                    key={priority}
                    size="sm"
                    variant={patient.priority === priority ? getPriorityVariant(priority) : "outline"}
                    onClick={() => onPriorityChange(patient.id, priority)}
                    className="capitalize"
                  >
                    {priority}
                  </Button>
                ))}
              </div>
            </div>

            {/* View Details */}
            <Button size="lg" asChild>
              <Link href={`/caretaker/patient/${patient.id}`}>View Details</Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
