"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"

export function PhoneOtpForm() {
  const [phone, setPhone] = useState("")
  const [otp, setOtp] = useState("")
  const [step, setStep] = useState<"phone" | "otp">("phone")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [canResend, setCanResend] = useState(false)

  const handleSendOtp = async () => {
    setLoading(true)
    setError("")

    // Simulate API call
    try {
      if (phone.length < 10) {
        throw new Error("invalid number length, please try again")
      }

      // Simulate sending OTP
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStep("otp")

      // Enable resend after 30 seconds
      setTimeout(() => setCanResend(true), 30000)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleVerifyOtp = async () => {
    setLoading(true)
    setError("")

    try {
      if (otp !== "123456") {
        // Demo OTP
        throw new Error("otp is wrong, pls try again")
      }

      // Simulate verification
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Redirect to role selection
      window.location.href = "/role-selection"
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">{step === "phone" ? "Enter Phone Number" : "Enter OTP"}</CardTitle>
        <CardDescription>
          {step === "phone" ? "We will send you a verification code" : "Enter the 6-digit code sent to your phone"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {step === "phone" ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="Enter your phone number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="text-lg"
              />
            </div>
            <Button onClick={handleSendOtp} disabled={loading || !phone} className="w-full text-lg py-6">
              {loading ? "Sending..." : "Send OTP"}
            </Button>
          </>
        ) : (
          <>
            <div className="space-y-2">
              <Label htmlFor="otp">Verification Code</Label>
              <Input
                id="otp"
                type="text"
                placeholder="Enter 6-digit code"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                maxLength={6}
                className="text-lg text-center tracking-widest"
              />
            </div>
            <Button onClick={handleVerifyOtp} disabled={loading || otp.length !== 6} className="w-full text-lg py-6">
              {loading ? "Verifying..." : "Verify OTP"}
            </Button>
            <Button variant="outline" onClick={() => setStep("phone")} className="w-full text-lg py-6">
              Change Phone Number
            </Button>
            {canResend && (
              <Button variant="ghost" onClick={handleSendOtp} className="w-full text-lg py-6">
                Resend OTP
              </Button>
            )}
          </>
        )}

        {error && <div className="text-destructive text-center font-medium">{error}</div>}
      </CardContent>
    </Card>
  )
}
