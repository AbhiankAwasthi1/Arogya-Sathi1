"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"

export function LoginForm() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async () => {
    setLoading(true)
    setError("")

    try {
      if (!username || !password) {
        throw new Error("Please fill in all fields")
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Demo credentials
      if (username === "demo" && password === "password123!") {
        window.location.href = "/role-selection"
      } else {
        throw new Error("Invalid username or password")
      }
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Welcome Back</CardTitle>
        <CardDescription>Sign in to your account</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="username">Username</Label>
          <Input
            id="username"
            type="text"
            placeholder="Enter your username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="text-lg"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="text-lg"
          />
        </div>

        <Button onClick={handleLogin} disabled={loading || !username || !password} className="w-full text-lg py-6">
          {loading ? "Signing In..." : "Sign In"}
        </Button>

        {error && <div className="text-destructive text-center font-medium">{error}</div>}
      </CardContent>
    </Card>
  )
}
