"use client"

import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"

export function CaptchaBox({ onVerify }: { onVerify: (verified: boolean) => void }) {
  const [verified, setVerified] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleCheck = async (checked: boolean) => {
    if (checked) {
      setLoading(true)
      // Simulate captcha verification
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setVerified(true)
      setLoading(false)
      onVerify(true)
    } else {
      setVerified(false)
      onVerify(false)
    }
  }

  return (
    <div className="flex items-center space-x-3 p-4 border rounded-lg bg-muted/50">
      <Checkbox id="captcha" checked={verified} onCheckedChange={handleCheck} disabled={loading} />
      <label htmlFor="captcha" className="text-lg font-medium cursor-pointer">
        {loading ? "Verifying..." : "I am not a robot"}
      </label>
    </div>
  )
}
