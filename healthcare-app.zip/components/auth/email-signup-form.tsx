"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"

export function EmailSignupForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [emailSent, setEmailSent] = useState(false)

  const handleSignup = async () => {
    setLoading(true)
    setError("")

    try {
      // Basic validation
      if (!email || !password) {
        throw new Error("Please fill in all fields")
      }

      if (password.length < 8 || !/\d/.test(password) || !/[!@#$%^&*]/.test(password)) {
        throw new Error("Password must be at least 8 characters with one number and one symbol")
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setEmailSent(true)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (emailSent) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Check Your Email</CardTitle>
          <CardDescription>We've sent a verification link to {email}</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="outline" onClick={() => setEmailSent(false)} className="w-full text-lg py-6">
            Back to Signup
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Create Account</CardTitle>
        <CardDescription>Sign up with your email address</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="text-lg"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            type="password"
            placeholder="Create a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="text-lg"
          />
          <p className="text-sm text-muted-foreground">At least 8 characters with one number and one symbol</p>
        </div>

        <Button onClick={handleSignup} disabled={loading || !email || !password} className="w-full text-lg py-6">
          {loading ? "Creating Account..." : "Sign Up"}
        </Button>

        {error && <div className="text-destructive text-center font-medium">{error}</div>}
      </CardContent>
    </Card>
  )
}
