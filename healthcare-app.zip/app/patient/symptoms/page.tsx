"use client"

import type React from "react"

import { useState } from "react"
import { PatientNav } from "@/components/patient/patient-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"

const commonSymptoms = [
  "Headache",
  "Fever",
  "Cough",
  "Fatigue",
  "Nausea",
  "Dizziness",
  "Chest Pain",
  "Shortness of Breath",
  "Joint Pain",
  "Stomach Pain",
]

export default function SymptomsPage() {
  const [symptoms, setSymptoms] = useState<any[]>([])
  const [formData, setFormData] = useState({
    symptom: "",
    customSymptom: "",
    severity: [5],
    description: "",
    triggers: "",
  })
  const [loading, setLoading] = useState(false)

  const getSeverityEmoji = (severity: number) => {
    if (severity <= 3) return "😀"
    if (severity <= 6) return "😐"
    return "😞"
  }

  const getSeverityColor = (severity: number) => {
    if (severity <= 3) return "bg-green-500"
    if (severity <= 6) return "bg-orange-500"
    return "bg-red-500"
  }

  const getSeverityLabel = (severity: number) => {
    if (severity <= 3) return "Mild"
    if (severity <= 6) return "Moderate"
    if (severity <= 8) return "High"
    return "Severe"
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    const symptomName = formData.symptom === "Other" ? formData.customSymptom : formData.symptom

    const newSymptom = {
      id: Date.now().toString(),
      name: symptomName,
      severity: formData.severity[0],
      description: formData.description,
      triggers: formData.triggers,
      timestamp: new Date(),
    }

    await new Promise((resolve) => setTimeout(resolve, 1000))
    setSymptoms([newSymptom, ...symptoms])
    setFormData({
      symptom: "",
      customSymptom: "",
      severity: [5],
      description: "",
      triggers: "",
    })
    setLoading(false)
  }

  const handleAIHelper = () => {
    alert(
      "AI Helper: Based on your description, this might be a moderate symptom. Consider consulting with your healthcare provider if it persists.",
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <PatientNav />

      <main className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Daily Symptom Tracker</h1>
          <p className="text-lg text-muted-foreground">Log your symptoms daily.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Symptom Entry Form */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Log New Symptom</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="symptom">Symptom</Label>
                  <Select
                    value={formData.symptom}
                    onValueChange={(value) => setFormData({ ...formData, symptom: value })}
                  >
                    <SelectTrigger className="text-lg">
                      <SelectValue placeholder="Select a symptom" />
                    </SelectTrigger>
                    <SelectContent>
                      {commonSymptoms.map((symptom) => (
                        <SelectItem key={symptom} value={symptom} className="text-lg">
                          {symptom}
                        </SelectItem>
                      ))}
                      <SelectItem value="Other" className="text-lg">
                        Other
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.symptom === "Other" && (
                  <div className="space-y-2">
                    <Label htmlFor="customSymptom">Custom Symptom</Label>
                    <Input
                      id="customSymptom"
                      placeholder="Describe your symptom"
                      value={formData.customSymptom}
                      onChange={(e) => setFormData({ ...formData, customSymptom: e.target.value })}
                      required
                      className="text-lg"
                    />
                  </div>
                )}

                <div className="space-y-4">
                  <Label>
                    Severity: {formData.severity[0]} - {getSeverityLabel(formData.severity[0])}
                  </Label>
                  <div className="px-2">
                    <Slider
                      value={formData.severity}
                      onValueChange={(value) => setFormData({ ...formData, severity: value })}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-muted-foreground mt-1">
                      <span>1 (Mild)</span>
                      <span>10 (Severe)</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your Symptom, when it started, what makes it better/worse"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="text-lg min-h-[100px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="triggers">Possible Triggers</Label>
                  <Input
                    id="triggers"
                    placeholder="e.g., stress, food, weather, poor sleep (separate with commas)"
                    value={formData.triggers}
                    onChange={(e) => setFormData({ ...formData, triggers: e.target.value })}
                    className="text-lg"
                  />
                </div>

                <div className="flex space-x-3">
                  <Button
                    type="submit"
                    size="lg"
                    className="flex-1 text-lg py-6"
                    disabled={loading || !formData.symptom}
                  >
                    {loading ? "Logging..." : "Log Symptom"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    className="text-lg py-6 bg-transparent"
                    onClick={handleAIHelper}
                  >
                    AI: trouble deciding?
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground text-center">
                  always seek professional advice before diagnosing disease on your own
                </p>
              </form>
            </CardContent>
          </Card>

          {/* Recent Symptoms */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Recent Symptoms</CardTitle>
            </CardHeader>
            <CardContent>
              {symptoms.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No symptoms logged yet</p>
              ) : (
                <div className="space-y-4">
                  {symptoms.map((symptom) => (
                    <div key={symptom.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{getSeverityEmoji(symptom.severity)}</span>
                          <div>
                            <h3 className="font-semibold text-lg">{symptom.name}</h3>
                            <p className="text-sm text-muted-foreground">
                              {symptom.timestamp.toLocaleDateString()} at {symptom.timestamp.toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                        {symptom.triggers && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {symptom.triggers.split(",").map((trigger: string, index: number) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {trigger.trim()}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-8 rounded ${getSeverityColor(symptom.severity)}`} />
                        <span className="font-medium">{symptom.severity}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
