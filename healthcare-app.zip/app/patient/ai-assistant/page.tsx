"use client"

import type React from "react"

import { useState } from "react"
import { PatientNav } from "@/components/patient/patient-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Plus } from "lucide-react"

interface Chat {
  id: string
  title: string
  timestamp: Date
  messages: Message[]
}

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
}

export default function AIAssistantPage() {
  const [chats, setChats] = useState<Chat[]>([])
  const [currentChat, setCurrentChat] = useState<Chat | null>(null)
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)

  const createNewChat = () => {
    const newChat: Chat = {
      id: Date.now().toString(),
      title: "New Chat",
      timestamp: new Date(),
      messages: [],
    }
    setChats([newChat, ...chats])
    setCurrentChat(newChat)
  }

  const sendMessage = async () => {
    if (!message.trim() || !currentChat) return

    setLoading(true)
    const userMessage: Message = {
      id: Date.now().toString(),
      content: message,
      sender: "user",
      timestamp: new Date(),
    }

    const updatedChat = {
      ...currentChat,
      messages: [...currentChat.messages, userMessage],
      title: currentChat.messages.length === 0 ? message.slice(0, 30) + "..." : currentChat.title,
    }

    setCurrentChat(updatedChat)
    setChats(chats.map((chat) => (chat.id === currentChat.id ? updatedChat : chat)))
    setMessage("")

    // Simulate AI response (placeholder)
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content:
          "I'm a placeholder AI assistant. In the full implementation, I would provide healthcare guidance and support.",
        sender: "ai",
        timestamp: new Date(),
      }

      const finalChat = {
        ...updatedChat,
        messages: [...updatedChat.messages, aiMessage],
      }

      setCurrentChat(finalChat)
      setChats(chats.map((chat) => (chat.id === currentChat.id ? finalChat : chat)))
      setLoading(false)
    }, 1000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <PatientNav />

      <main className="max-w-6xl mx-auto p-6">
        <div className="grid lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
          {/* Chat History Sidebar */}
          <Card className="lg:col-span-1">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Chats</CardTitle>
                <Button size="sm" onClick={createNewChat}>
                  <Plus className="w-4 h-4 mr-1" />
                  New Chat
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                {chats.length === 0 ? (
                  <p className="text-center text-muted-foreground p-4">No previous chats</p>
                ) : (
                  <div className="space-y-2 p-4">
                    {chats.map((chat) => (
                      <Button
                        key={chat.id}
                        variant={currentChat?.id === chat.id ? "secondary" : "ghost"}
                        className="w-full justify-start text-left h-auto p-3"
                        onClick={() => setCurrentChat(chat)}
                      >
                        <div>
                          <p className="font-medium truncate">{chat.title}</p>
                          <p className="text-xs text-muted-foreground">{chat.timestamp.toLocaleDateString()}</p>
                        </div>
                      </Button>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Chat Interface */}
          <Card className="lg:col-span-3">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{currentChat ? currentChat.title : "AI Assistant"}</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col h-[500px]">
              {/* Messages Area */}
              <ScrollArea className="flex-1 mb-4">
                {!currentChat ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center">
                      <p className="text-lg text-muted-foreground mb-4">Start a new conversation</p>
                      <Button onClick={createNewChat}>
                        <Plus className="w-4 h-4 mr-2" />
                        New Chat
                      </Button>
                    </div>
                  </div>
                ) : currentChat.messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">Start typing to begin your conversation...</p>
                  </div>
                ) : (
                  <div className="space-y-4 p-4">
                    {currentChat.messages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[80%] p-3 rounded-lg ${
                            msg.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          <p className="text-base">{msg.content}</p>
                          <p className="text-xs opacity-70 mt-1">{msg.timestamp.toLocaleTimeString()}</p>
                        </div>
                      </div>
                    ))}
                    {loading && (
                      <div className="flex justify-start">
                        <div className="bg-muted p-3 rounded-lg">
                          <p className="text-base">Thinking...</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </ScrollArea>

              {/* Input Area */}
              <div className="flex space-x-2">
                <Input
                  placeholder="Type your message..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={loading}
                  className="text-lg"
                />
                <Button onClick={sendMessage} disabled={loading || !message.trim() || !currentChat} size="lg">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
