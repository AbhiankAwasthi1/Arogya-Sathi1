"use client"

import { useState } from "react"
import { PatientNav } from "@/components/patient/patient-nav"
import { MedicationCard } from "@/components/patient/medication-card"
import { AddMedicationForm } from "@/components/patient/add-medication-form"

export default function PatientHomePage() {
  const [medications, setMedications] = useState<any[]>([])

  const handleAddMedication = (medication: any) => {
    setMedications([...medications, medication])
  }

  const handleMarkTaken = (id: string) => {
    setMedications(medications.map((med) => (med.id === id ? { ...med, taken: true } : med)))
  }

  const handleMarkMissed = (id: string) => {
    setMedications(medications.map((med) => (med.id === id ? { ...med, taken: false } : med)))
  }

  return (
    <div className="min-h-screen bg-background">
      <PatientNav />

      <main className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Today's Medications</h1>
          <p className="text-lg text-muted-foreground">Keep track of your daily medications and stay healthy</p>
        </div>

        <div className="space-y-6">
          {medications.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-muted-foreground mb-6">
                No medications added yet. Add your first medication below.
              </p>
            </div>
          ) : (
            <div className="grid gap-6">
              {medications.map((medication) => (
                <MedicationCard
                  key={medication.id}
                  medication={medication}
                  onMarkTaken={handleMarkTaken}
                  onMarkMissed={handleMarkMissed}
                />
              ))}
            </div>
          )}

          <AddMedicationForm onAdd={handleAddMedication} />
        </div>
      </main>
    </div>
  )
}
