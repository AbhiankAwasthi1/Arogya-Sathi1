"use client"

import { PatientNav } from "@/components/patient/patient-nav"
import { LanguageSelector } from "@/components/settings/language-selector"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function PatientLanguagePage() {
  return (
    <div className="min-h-screen bg-background">
      <PatientNav />

      <main className="max-w-2xl mx-auto p-6">
        <div className="mb-8">
          <Button variant="ghost" size="lg" asChild className="mb-4">
            <Link href="/patient">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </Button>

          <h1 className="text-3xl font-bold mb-2">Language Settings</h1>
          <p className="text-lg text-muted-foreground">Choose your preferred language for the interface</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Select Your Language</CardTitle>
          </CardHeader>
          <CardContent>
            <LanguageSelector />
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
