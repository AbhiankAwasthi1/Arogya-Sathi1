import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, User } from "lucide-react"
import Link from "next/link"

export default function RoleSelectionPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Choose Your Role</h1>
          <p className="text-xl text-muted-foreground">Select how you'll be using our healthcare platform</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Patient Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-4 bg-primary/10 rounded-full w-fit">
                <User className="w-12 h-12 text-primary" />
              </div>
              <CardTitle className="text-2xl">Patient</CardTitle>
              <CardDescription className="text-lg">
                Manage your medications, track symptoms, and stay healthy
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button size="lg" className="w-full text-xl py-6" asChild>
                <Link href="/patient">Continue as Patient</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Caretaker Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-4 bg-primary/10 rounded-full w-fit">
                <Users className="w-12 h-12 text-primary" />
              </div>
              <CardTitle className="text-2xl">Caretaker</CardTitle>
              <CardDescription className="text-lg">
                Monitor and assist patients with their healthcare needs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button size="lg" className="w-full text-xl py-6" asChild>
                <Link href="/caretaker">Continue as Caretaker</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
