"use client"

import { useState } from "react"
import { CaretakerNav } from "@/components/caretaker/caretaker-nav"
import { PatientRow } from "@/components/caretaker/patient-row"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function CaretakerDashboardPage() {
  const [patients, setPatients] = useState([
    {
      id: "1",
      name: "John Smith",
      phone: "+1-555-0123",
      priority: "medium" as const,
      adherence: 85,
      recentMisses: 1,
      lastActivity: new Date(),
      avatar: "/placeholder.svg?height=64&width=64",
    },
  ])

  const [requests] = useState([
    {
      id: "1",
      patientName: "John Smith",
      type: "medication_request",
      message: "Cannot add medication by myself",
      timestamp: new Date(),
    },
  ])

  const handlePriorityChange = (id: string, priority: "low" | "medium" | "high") => {
    setPatients(
      patients
        .map((patient) => (patient.id === id ? { ...patient, priority } : patient))
        .sort((a, b) => {
          const priorityOrder = { high: 3, medium: 2, low: 1 }
          return priorityOrder[b.priority] - priorityOrder[a.priority]
        }),
    )
  }

  // Sort patients by priority
  const sortedPatients = [...patients].sort((a, b) => {
    const priorityOrder = { high: 3, medium: 2, low: 1 }
    return priorityOrder[b.priority] - priorityOrder[a.priority]
  })

  return (
    <div className="min-h-screen bg-background">
      <CaretakerNav />

      <main className="max-w-6xl mx-auto p-6">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Patient List */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Your Patients</h2>
              <p className="text-muted-foreground">Monitor and manage patient health status</p>
            </div>

            <div className="space-y-4">
              {sortedPatients.map((patient) => (
                <PatientRow key={patient.id} patient={patient} onPriorityChange={handlePriorityChange} />
              ))}
            </div>
          </div>

          {/* Requests Panel */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Patient Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {requests.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No pending requests</p>
                ) : (
                  <div className="space-y-4">
                    {requests.map((request) => (
                      <div key={request.id} className="p-4 border rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold">{request.patientName}</h4>
                          <Badge variant="secondary">New</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{request.message}</p>
                        <p className="text-xs text-muted-foreground">{request.timestamp.toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-xl">Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Patients</span>
                    <span className="font-semibold">{patients.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>High Priority</span>
                    <span className="font-semibold text-red-600">
                      {patients.filter((p) => p.priority === "high").length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pending Requests</span>
                    <span className="font-semibold">{requests.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg. Adherence</span>
                    <span className="font-semibold">
                      {Math.round(patients.reduce((acc, p) => acc + p.adherence, 0) / patients.length)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
