"use client"

import type React from "react"

import { useState } from "react"
import { CaretakerNav } from "@/components/caretaker/caretaker-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"

export default function AddPatientPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Redirect back to dashboard
    router.push("/caretaker")
  }

  return (
    <div className="min-h-screen bg-background">
      <CaretakerNav />

      <main className="max-w-2xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Add New Patient</h1>
          <p className="text-lg text-muted-foreground">Add a patient to monitor their health and medications</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Patient Information</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Patient Name</Label>
                <Input
                  id="name"
                  placeholder="Enter patient's full name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="text-lg"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter patient's phone number"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                  className="text-lg"
                />
              </div>

              <div className="flex space-x-3">
                <Button
                  type="submit"
                  size="lg"
                  className="flex-1 text-lg py-6"
                  disabled={loading || !formData.name || !formData.phone}
                >
                  {loading ? "Adding Patient..." : "Add Patient"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  className="flex-1 text-lg py-6 bg-transparent"
                  onClick={() => router.push("/caretaker")}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
