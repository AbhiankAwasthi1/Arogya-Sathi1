"use client"

import { useState } from "react"
import { CaretakerNav } from "@/components/caretaker/caretaker-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Phone, AlertTriangle } from "lucide-react"
import { useParams } from "next/navigation"

export default function CurrentHealthPage() {
  const params = useParams()
  const patientId = params.id

  // Mock patient data
  const [patient] = useState({
    id: patientId,
    name: "John Smith",
    phone: "+1-555-0123",
    priority: "medium" as const,
    avatar: "/placeholder.svg?height=64&width=64",
  })

  const [symptoms] = useState([
    {
      id: "1",
      name: "Headache",
      severity: 6,
      timestamp: new Date(),
    },
    {
      id: "2",
      name: "Fatigue",
      severity: 4,
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    },
  ])

  const [medications] = useState([
    {
      id: "1",
      name: "Aspirin",
      dosage: "500mg",
      schedule: "Twice daily",
      taken: true,
      lastTaken: new Date(Date.now() - 2 * 60 * 60 * 1000),
    },
    {
      id: "2",
      name: "Metformin",
      dosage: "1000mg",
      schedule: "Once daily",
      taken: false,
      lastTaken: new Date(Date.now() - 26 * 60 * 60 * 1000),
    },
  ])

  const getSeverityEmoji = (severity: number) => {
    if (severity <= 3) return "😀"
    if (severity <= 6) return "😐"
    return "😞"
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleCall = () => {
    window.open(`tel:${patient.phone}`, "_self")
  }

  const handlePriorityChange = (newPriority: "low" | "medium" | "high") => {
    // Update priority logic here
    console.log("Priority changed to:", newPriority)
  }

  const takenCount = medications.filter((m) => m.taken).length
  const totalCount = medications.length

  return (
    <div className="min-h-screen bg-background">
      <CaretakerNav />

      <main className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">Current Health</h1>

          {/* Patient Header */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={patient.avatar || "/placeholder.svg"} alt={patient.name} />
                  <AvatarFallback className="text-xl font-semibold">
                    {patient.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h2 className="text-2xl font-bold">{patient.name}</h2>
                    <div className={`w-5 h-5 rounded ${getPriorityColor(patient.priority)}`} />
                  </div>
                  <Button variant="outline" onClick={handleCall} className="text-lg bg-transparent">
                    <Phone className="w-4 h-4 mr-2" />
                    {patient.phone}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          {/* Symptoms */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2" />
                Symptoms
              </CardTitle>
            </CardHeader>
            <CardContent>
              {symptoms.length === 0 ? (
                <p className="text-muted-foreground">No symptoms reported</p>
              ) : (
                <div className="space-y-3">
                  {symptoms.map((symptom) => (
                    <div key={symptom.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{getSeverityEmoji(symptom.severity)}</span>
                        <div>
                          <h4 className="font-semibold">{symptom.name}</h4>
                          <p className="text-sm text-muted-foreground">{symptom.timestamp.toLocaleDateString()}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-lg px-3 py-1">
                        {symptom.severity}/10
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Medication Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Medication Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="text-3xl font-bold text-green-600">{takenCount}</div>
                  <div className="text-sm text-muted-foreground">Taken Today</div>
                </div>
                <div className="text-center p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <div className="text-3xl font-bold text-red-600">{totalCount - takenCount}</div>
                  <div className="text-sm text-muted-foreground">Missed Today</div>
                </div>
              </div>

              {/* Detailed Medication List */}
              <div className="space-y-3">
                <h4 className="font-semibold text-lg mb-3">Detailed Medication List</h4>
                {medications.map((medication) => (
                  <div key={medication.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-1">
                        <h5 className="font-semibold">{medication.name}</h5>
                        <Badge variant={medication.taken ? "secondary" : "destructive"}>
                          {medication.taken ? "Taken" : "Not Taken"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {medication.dosage} • {medication.schedule}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Last taken: {medication.lastTaken.toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Priority Assignment */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Priority Assignment</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <span className="font-medium">Current Priority:</span>
                <div className="flex space-x-2">
                  {(["low", "medium", "high"] as const).map((priority) => (
                    <Button
                      key={priority}
                      size="lg"
                      variant={patient.priority === priority ? "default" : "outline"}
                      onClick={() => handlePriorityChange(priority)}
                      className={`capitalize ${
                        priority === "high"
                          ? "border-red-500 text-red-600"
                          : priority === "medium"
                            ? "border-yellow-500 text-yellow-600"
                            : "border-green-500 text-green-600"
                      }`}
                    >
                      <div className={`w-3 h-3 rounded mr-2 ${getPriorityColor(priority)}`} />
                      {priority}
                    </Button>
                  ))}
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Changing priority will reorder the patient list immediately
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
